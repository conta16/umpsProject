#ifndef HANDLERS_H
#define HANDLERS_H
void tlb_handler(void);
void pgmtrap_handler(void);
void sysbk_handler(void);

#endif
